package Test;


public class Print {

	public static void main (String[] arg) {
		
		System.out.print("Hello World");
	}
}
